"""
mazegen - A maze generator using Hunt and Kill algorithm.

Example usage:
    from mazegen import MazeGenerator, bfs

    # Create and generate maze
    gen = MazeGenerator(width=20, height=20, seed=42)
    maze = gen.generate()

    # Find shortest path
    entry = (0, 0)
    exit_ = (19, 19)
    path = bfs(maze, entry, exit_)
    print(f"Path: {path}")
"""

from .generator import MazeGenerator
from .maze import Maze, NORTH, EAST, SOUTH, WEST
from .pathfinding import bfs, dfs

__version__ = "1.0.0"
__all__ = [
    "MazeGenerator",
    "Maze",
    "bfs",
    "dfs",
    "NORTH",
    "EAST",
    "SOUTH",
    "WEST",
]